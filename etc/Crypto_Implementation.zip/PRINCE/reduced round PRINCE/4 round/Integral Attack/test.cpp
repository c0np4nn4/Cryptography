#include <cstdio>
#include "4_round_PRINCE.h"


#define KEY_EXPANSION_MASK 0x7fffffffffffffff
u4 estimated_key_counter[16][16] = {0x0, };

//u4 estimated_key_counter[16][16] = {0x0, };
//
//void s_layer_nibble(u4 nibble_in, u4& nibble_out) {
//	u4 sBox[16] = { 0xB, 0xF, 0x3, 0x2, 
//					0xA, 0xC, 0x9, 0x1, 
//					0x6, 0x7, 0x8, 0x0, 
//					0xE, 0x5, 0xD, 0x4 };
//	nibble_out = sBox[nibble_in];
// }
// 
//void get_guessed_k1_xor_k0_prime(u64* ct, u64& k1_xor_k0_prime) {
//	u4 ct_nibble[16];
//	u4 guessed_k_nibble = 0x0;
//	
//	u64 rc3 = 0x082efa98ec4e6c89;
//	u4 rc3_nibble = 0x0;
//	
//	for (int count = 0; count < 16; count++) {
//		
//		rc3_nibble = rc3 & 0xf;
//		rc3 = rc3 >> static_cast<u64>(4);
//		
//		
//		for (guessed_k_nibble = 0; guessed_k_nibble <= 0xf; guessed_k_nibble++) {
//			for (int i = 0; i < 16; i++) {
//				ct_nibble[i] = (ct[i] >> static_cast<u4>(4 * count)) & 0x0f;
//			}
//			
//			
//			for (int i = 0; i < 16; i++) {
//				// 0.5 round backward
//				s_layer_nibble( ct_nibble[i] ^ guessed_k_nibble ^ rc3_nibble, ct_nibble[i] );
//			}
//			
//			/**
//			 * TEST
//			*/
//			u64 guessed_ct = 0x0;
//			for (int i = 0; i < 16; i++) {
//				guessed_ct <<= 4;
//				guessed_ct |= ct_nibble[i];
//			}
//			
//			u64 tmp;
//			m_layer(guessed_ct, tmp);
//			
//			for (int i = 15; i >= 0; i--) {
//				ct_nibble[i] = tmp & 0xf;
//				tmp >>= 4;
//			}
//
//
//			u4 is_balanced = 0x0;
//			for (int i = 0; i < 16; i++) {
//				is_balanced ^= ct_nibble[i];
//			}
//			
//			/* ---------------------------------------------- */
//			
//			if (0 == is_balanced) {
////				printf("[FOUND!] : [%.2d] %llx\n", 16 - count, guessed_k_nibble);
//				estimated_key_counter[15 - count][guessed_k_nibble]++;
//				
//			}
//			else {
//			//	printf("[FAIL.....] : %llx\n", guessed_k_nibble);
//			}
//			
//
//			
//			
//		}
//	}
//}

int main() {
	
	/*
	 * TEST
	 *
	*/	 
	u64 key[2];
	key[0] = 0x0000000000000000;
	key[1] = 0x000f0cc00cafea01;
	u64 pt = 0x0000000000000000;
	u64 ct = 0x0;
	
	u64 k0_prime = ( ((key[0] >> static_cast<u64>(1)) & KEY_EXPANSION_MASK ) | (key[0] << static_cast<u64>(63)) ) ^ ( key[0] >> static_cast<u64>(63) );
	
	u64 k1_xor_k0_prime = 0x0;
	
	u64 ct_set[5][16];
	
	printf("       k0` == 0x%0.16llx\n", k0_prime);
	printf("       k1  == 0x%0.16llx\n", key[1]);
	printf("k1 xor k0' == 0x%0.16llx\n", k0_prime ^ key[1]);
	

	u64 index = 0x01;
	for (int c = 0; c < 5; c++) {
		pt = 0x0;
		for (int i = 0; i < 16; i++) {
			encrypt(key, pt, ct);
			ct_set[c][i] = ct;
			pt += index;
		}
		index = index << 4;
	}
	
//	u64 guessed_key;
//	round_4_integral_attack(ct_set, guessed_key);
//	
//	printf("guessed_key== 0x%0.16llx\n", guessed_key);



	/*
	pt = 0x0;
	for (int i = 0; i < 16; i++) {
		encrypt(key, pt, ct);
		ct_set[i] = ct;
		pt += 0x10;
	}
	get_guessed_k1_xor_k0_prime(ct_set, k1_xor_k0_prime);
	
	pt = 0x0;
	for (int i = 0; i < 16; i++) {
		encrypt(key, pt, ct);
		ct_set[i] = ct;
		pt += 0x0100;
	}
	get_guessed_k1_xor_k0_prime(ct_set, k1_xor_k0_prime);
	
	pt = 0x0;
	for (int i = 0; i < 16; i++) {
		encrypt(key, pt, ct);
		ct_set[i] = ct;
		pt += 0x1000;
	}
	get_guessed_k1_xor_k0_prime(ct_set, k1_xor_k0_prime);
	
	pt = 0x0;
	for (int i = 0; i < 16; i++) {
		encrypt(key, pt, ct);
		ct_set[i] = ct;
		pt += 0x010000;
	}
	get_guessed_k1_xor_k0_prime(ct_set, k1_xor_k0_prime);
	
	
//	printf("RESULT!!\n");
//	for (int i = 0; i < 16; i++) {
//		printf("[%d]\n", i);
//		for (int j = 0; j < 16; j++) {
//			printf("%d ", estimated_key_counter[i][j]);
//		}
//		printf("\n");
//	}
	
	*/
	u64 guessed_key = 0x0;
	for (int i = 0; i < 16; i++) {
		for (int j = 0; j < 16; j++) {
			if (estimated_key_counter[i][j] == 5) {
				guessed_key <<= 4;
				guessed_key |= j;
			}
		}
	}
	printf("guessed_key== 0x%0.16llx\n", guessed_key);
	
	
	
	return 0;
}
