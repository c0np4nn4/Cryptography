#include <cstdint>
#include <cstdio>

#define KEY_EXPANSION_MASK 0x7fffffffffffffff


typedef unsigned int u4;		// for nibble
typedef uint8_t u8;
typedef uint16_t u16;
typedef uint32_t u32;
typedef uint64_t u64;

void s_layer(u64&, u64&);
void inv_s_layer(u64&, u64&);
void sr_layer(u64&, u64&);
void inv_sr_layer(u64&, u64&);
void m_layer(u64& prev_state, u64& curr_state);
void encrypt(u64 key[2], u64& plaintext, u64& ciphertext);
void decrypt(u64 key[2], u64& ciphertext);
