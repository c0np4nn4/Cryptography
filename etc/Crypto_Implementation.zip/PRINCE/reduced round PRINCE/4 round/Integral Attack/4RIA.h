#include <cstdint>

typedef unsigned int u4;		// for nibble
typedef uint64_t u64;

void round_4_integral_attack(u64 (*)[16], u64&);
