var searchData=
[
  ['mask_5fcol_0',['mask_col',['../prince__core_8cpp.html#ad940b40ee884122322b57d57a1d63716',1,'prince_core.cpp']]]
];
