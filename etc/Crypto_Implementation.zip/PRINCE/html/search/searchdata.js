var indexSectionsWithContent =
{
  0: "deiklmprstu",
  1: "kpt",
  2: "deiklmrs",
  3: "imrs",
  4: "u",
  5: "m"
};

var indexSectionNames =
{
  0: "all",
  1: "files",
  2: "functions",
  3: "variables",
  4: "typedefs",
  5: "defines"
};

var indexSectionLabels =
{
  0: "모두",
  1: "파일들",
  2: "함수",
  3: "변수",
  4: "타입정의",
  5: "매크로"
};

