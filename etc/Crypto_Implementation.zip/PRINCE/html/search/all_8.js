var searchData=
[
  ['s_5flayer_0',['s_layer',['../prince__core_8cpp.html#a6f16791842408ba85f323972b6715469',1,'s_layer(u64 &amp;, u64 &amp;):&#160;prince_core.cpp'],['../prince__core_8h.html#a6f16791842408ba85f323972b6715469',1,'s_layer(u64 &amp;, u64 &amp;):&#160;prince_core.cpp']]],
  ['sbox_1',['sBox',['../prince__core_8cpp.html#ae8474060ee600ec678a5564ea86af0d2',1,'prince_core.cpp']]],
  ['sr_5flayer_2',['sr_layer',['../prince__core_8cpp.html#a687dfedb9ba64e36d4cc2c0b33165d52',1,'sr_layer(u64 &amp;, u64 &amp;):&#160;prince_core.cpp'],['../prince__core_8h.html#a687dfedb9ba64e36d4cc2c0b33165d52',1,'sr_layer(u64 &amp;, u64 &amp;):&#160;prince_core.cpp']]]
];
