#include <cstdio>
#include <cstdint>
#define KEY_EXPANSION_MASK 0x7fffffffffffffff

typedef unsigned int u4;
typedef uint8_t u8;
typedef uint16_t u16;
typedef uint32_t u32;
typedef uint64_t u64;

void key_expansion(u64& k0, u64& k2) {
	// k2
	u64 rotate_right_1bit = ((k0 >> static_cast<u64>(1)) & KEY_EXPANSION_MASK ) | (k0 << static_cast<u64>(63));
	u64 shift_right_63bit = k0 >> static_cast<u64>(63);
	
	k2 = rotate_right_1bit ^ shift_right_63bit;
}
	
void s_layer(u64& prev_state, u64& curr_state) {
	u4 sBox[16] = { 0xB, 0xF, 0x3, 0x2, 0xA, 0xC, 0x9, 0x1, 0x6, 0x7, 0x8, 0x0, 0xE, 0x5, 0xD, 0x4};
	
	u64 tmp = 0x0;
	for (int i = 0; i < 16; i++) {
		tmp = tmp << 4;
		u4 nibble;
		nibble = (prev_state & 0xf000000000000000) >> 60;
//		printf("%d nibble : %llx\n", i, nibble);				// get nibble
		/* Substitution */
		nibble = sBox[nibble];
		tmp = tmp | nibble;
//		printf("%d tmp : %llx\n", i, tmp);
		prev_state = prev_state << 4;
	}
	curr_state = tmp;
}
void inv_s_layer(u64& prev_state, u64& curr_state) {
	u4 inv_sBox[16] = { 0xB, 0x7, 0x3, 0x2, 0xF, 0xD, 0x8, 0x9, 0xA, 0x6, 0x4, 0x0, 0x5, 0xE, 0xC, 0x1};
	u64 tmp = 0x0;
	for (int i = 0; i < 16; i++) {
		tmp = tmp << 4;
		u4 nibble;
		nibble = (prev_state & 0xf000000000000000) >> 60;
//		printf("%d nibble : %llx\n", i, nibble);				// get nibble
		/* Substitution */
		nibble = inv_sBox[nibble];
		tmp = tmp | nibble;
//		printf("%d tmp : %llx\n", i, tmp);
		prev_state = prev_state << 4;
	}
	curr_state = tmp;
}
/* S Layer ================================================================ */

int main() {
	
	
	return 0;
}
