#include <cstdint>

typedef uint64_t u64;

void key_expansion(u64& k0, u64& k2);
