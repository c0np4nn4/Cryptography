#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define SIZE 64000000	// 64,000,000

void padding(unsigned char* origin_pt, unsigned char* padded_pt, unsigned int pad_c) {
	//pad
	char c = (char) pad_c;
	char* char_pad = (char*) malloc( sizeof(char) * pad_c );
	for (int i = 0; i < pad_c; i++) {
		char_pad[i] = pad_c;
	}
	
	for (int i = 0; i < pad_c; i++) {
		printf("%d ", char_pad[i]);
	}
	
	strcat(origin_pt, char_pad);
	
	strcpy(padded_pt, origin_pt);
	
}
