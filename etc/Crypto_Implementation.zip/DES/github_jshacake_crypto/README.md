# crypto_implementation



오전 9:52 2021-03-20 

TODO : 

Bit Rotate 1 에서 .. KBL, KBR 은 7-Byte 만을 이용함.

​	따라서, 지금 unsigned char 하나 만큼 Rotate 하는 것이 아니라

​	bit 하나 만큼 Rotate 하도록 코드를 수정해야 함.



오키도키?

