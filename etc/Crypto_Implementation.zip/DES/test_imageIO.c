#define _CRT_SECURE_NO_WARNINGS		// fopen �� vulnerable�� ���� 
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "des.h"
#include "padding.h"

//=-=-=--=-=--=-=-=-=-=----=-=-=-
#include "mode.h"
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=

// size 64,000,000

unsigned char k[8] = {0x0,};	// key

char a;

int main() {
	FILE *src = fopen("image.jpg", "rb");
	FILE *dst = fopen("enc_file", "wb");
	
	mode_ECB(src, dst, k);
//	while (!feof(src)) {
//		for (int i = 0; i < 8; i++) {
//			p[i] = fgetc(src);
//		}
//		
//		enc(p, k, c);
//		
////		dec(c, k, p);
//		
//		for (int i = 0; i < 8; i++) {
//			fputc(p[i], dst);
//		}
//	}
//	printf("\n");
	
	fclose(src);
	fclose(dst);
	
	return 0;
}
