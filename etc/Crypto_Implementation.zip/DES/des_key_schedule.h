void key_schedule(unsigned char k[8], unsigned char rks[16][6]);
