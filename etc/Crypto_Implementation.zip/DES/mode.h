/*
	@ name : mode_ECB
	@@ input : FILE* src, FILE* dst, unsigned char k[8]
	@@ output : void
	@@@ caller : user
*/

void mode_ECB(FILE* src, FILE* dst, unsigned char k[8]);

