/*
	@ origin_pt		<-- original size
	@ padded_pt 	<-- modified size
*/

void padding(unsigned char* origin_pt, unsigned char* padded_pt, unsigned int pad_c);
