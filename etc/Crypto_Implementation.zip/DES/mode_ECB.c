#include <stdio.h>
#include "des.h"
#include "padding.h"

unsigned char p[8] = {0x0,};	// plaintext
unsigned char c[8] = {0x0,};	// ciphertext

void mode_ECB(FILE* src, FILE* dst, unsigned char k[8]) {
	while (!feof(src)) {
		for (int i = 0; i < 8; i++) {
			p[i] = fgetc(src);
		}
		
		enc(p, k, c);
		
//		dec(c, k, p);
		
		for (int i = 0; i < 8; i++) {
			fputc(p[i], dst);
		}
	}
	printf("\n");
}
